package com.example.taskexample.room;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.taskexample.network.json.Metadatum;

import java.util.List;

public class MetadatumViewModel extends AndroidViewModel {

    private MetadatumRepository metadatumRepository;
    private LiveData<List<Metadatum>> allResults;

    public MetadatumViewModel(@NonNull Application application) {
        super ( application );
        metadatumRepository = new MetadatumRepository ( application );
        allResults = metadatumRepository.getAllResults ();
    }

    public void insert(Metadatum metadatum){
        metadatumRepository.insert ( metadatum );
    }
    public void delete(Metadatum metadatum){
        metadatumRepository.delete ( metadatum );
    }
    public void deleteAll(){
        metadatumRepository.deleteAll ();
    }
    public LiveData<List<Metadatum>> getAllResults(){
        return allResults;
    }

    public void setAllResults(LiveData<List<Metadatum>> allResults) {
        this.allResults = allResults;
    }
}
