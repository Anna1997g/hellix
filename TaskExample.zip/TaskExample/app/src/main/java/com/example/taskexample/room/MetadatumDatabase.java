package com.example.taskexample.room;

import android.app.Application;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.taskexample.network.json.Metadatum;

@Database(entities = Metadatum.class,version = 1)
public abstract class MetadatumDatabase extends RoomDatabase {
    abstract MetadatumDao metadatumDao();
    private static MetadatumDatabase instance;

    public static synchronized MetadatumDatabase getInstance(Application application){
        if(instance==null){
            instance = Room.databaseBuilder(application, MetadatumDatabase.class, "metadatums")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }

}
