package com.example.taskexample.glideUtils;

import android.widget.ImageView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.taskexample.R;

public class GlideUtils {

    public static void setImage(ImageView imageView, String imageUrl, int radius) {
        RequestOptions requestOptions = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .skipMemoryCache(true)
                .transforms(new CenterCrop(), new RoundedCorners(radius));
        GlideApp.with(imageView.getContext())
                .load(imageUrl)
                .apply(requestOptions)
                .placeholder(R.drawable.ic_launcher_background)
                .into(imageView);
    }
}
