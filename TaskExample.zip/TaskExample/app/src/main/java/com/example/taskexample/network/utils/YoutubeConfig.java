package com.example.taskexample.network.utils;

public class YoutubeConfig {
    private static final String API_KEY = "AIzaSyCQzX3T30jg6YgDeh_GZHWkZF0BiBuL1Wk";


    public YoutubeConfig() {
    }

    public static String getApiKey() {
        return API_KEY;
    }
}
