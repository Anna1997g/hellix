package com.example.taskexample.network.retrofit;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.example.taskexample.room.MetadatumViewModel;
import com.example.taskexample.network.json.Metadatum;

import java.util.List;

public class RetrofitViewModel extends MetadatumViewModel {
    private RetrofitRepository retrofitRepository;
    private MutableLiveData<List<Metadatum>> metadatums;

    public RetrofitViewModel(@NonNull Application application) {
        super(application);
        retrofitRepository = new RetrofitRepository();
        metadatums = retrofitRepository.getAllResults();
    }
    public void search(){
        retrofitRepository.search ();
    }

    public MutableLiveData<List<Metadatum>> getMetadatums() {
        return metadatums;
    }
}
