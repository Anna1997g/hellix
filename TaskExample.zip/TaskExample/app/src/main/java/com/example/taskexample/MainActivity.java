package com.example.taskexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.example.taskexample.adapters.MetadatumAdapter;
import com.example.taskexample.activity.DetailsActivity;
import com.example.taskexample.network.json.BaseResult;
import com.example.taskexample.network.json.Metadatum;
import com.example.taskexample.network.retrofit.RequestManager;
import com.example.taskexample.network.retrofit.RetrofitViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity implements RequestManager.OnSearchListener {

    private RecyclerView rvMain;
    private MetadatumAdapter metadatumAdapter;
    private MutableLiveData<List<Metadatum>> metadatumsList;
    private RetrofitViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMain = findViewById(R.id.rv_main);
        metadatumAdapter = new MetadatumAdapter(this);


        rvMain.setLayoutManager(new LinearLayoutManager(this));
        rvMain.setAdapter(metadatumAdapter);
        setMetadatumListener(metadatumAdapter);

        viewModel = new RetrofitViewModel(getApplication());
        viewModel.search();
        viewModel.setAllResults(viewModel.getMetadatums());
        viewModel.getAllResults().observe(this, new Observer<List<Metadatum>>() {
            @Override
            public void onChanged(List<Metadatum> metadatumList) {
                metadatumAdapter.setMetadatumList(metadatumList);
            }
        });


    }

    private void setMetadatumListener(final MetadatumAdapter metadatumAdapter) {
        metadatumAdapter.setListener(new MetadatumAdapter.onitemClicklListener() {
            @Override
            public void onItemClicked(int position) {
                Metadatum metadatum = metadatumAdapter.getMetadatumList().get(position);
                if (metadatum.getClicked() == false) {
                    metadatum.setClicked(true);

                }
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                intent.putExtra("metadatum", metadatum);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        MetadatumAdapter metadatumAdapter1 = new MetadatumAdapter(this);
        metadatumAdapter1.setMetadatumList(viewModel.getMetadatums().getValue());
        setMetadatumListener(metadatumAdapter1);

        rvMain.setAdapter(metadatumAdapter1);

    }

    @Override
    public void onSearchSuccess(BaseResult baseResult) {

    }

    @Override
    public void onFailure(String failureMsg) {
        Toast.makeText(this, "Search failed", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(String msg) {
        Toast.makeText(this, "Search Error", Toast.LENGTH_SHORT).show();
    }


}
