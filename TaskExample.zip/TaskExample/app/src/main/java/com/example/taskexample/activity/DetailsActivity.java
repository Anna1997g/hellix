package com.example.taskexample.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.taskexample.R;
import com.example.taskexample.glideUtils.GlideApp;
import com.example.taskexample.glideUtils.GlideUtils;
import com.example.taskexample.network.json.Gallery;
import com.example.taskexample.network.json.Metadatum;
import com.example.taskexample.network.json.Video;
import com.example.taskexample.network.utils.DateUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DetailsActivity extends AppCompatActivity {
    private TextView tvDetailsTitle,tvDetailsCategory,tvDetailsDate,tvDetailsBody;
    private ImageView ivDetailsImage;
    private Button btnGallery,btnVideo;
    private List<Gallery> galleryList;
    private List<Video> videoList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        onCreateView();
        Intent intent = getIntent();
        tvDetailsBody.setMovementMethod(new ScrollingMovementMethod());
        Metadatum metadatum = (Metadatum) intent.getSerializableExtra("metadatum");
        tvDetailsTitle.setText(metadatum.getTitle());
        tvDetailsCategory.setText(metadatum.getCategory());
        tvDetailsBody.setText(metadatum.getBody());
        tvDetailsDate.setText(DateUtils.setDate(metadatum.getDate().toString()));
        GlideUtils.setImage(ivDetailsImage,metadatum.getCoverPhotoUrl(),8);
        galleryList = metadatum.getGallery();
        videoList = metadatum.getVideo();

        videoCheck();
        galleryCheck();



    }

    private void onCreateView(){
        tvDetailsTitle = findViewById(R.id.tv_details_title);
        tvDetailsCategory = findViewById(R.id.tv_details_category);
        tvDetailsDate = findViewById(R.id.tv_details_date);
        tvDetailsBody = findViewById(R.id.tv_details_body);
        ivDetailsImage = findViewById(R.id.iv_details_image);
        btnGallery = findViewById(R.id.btn_gallery);
        btnVideo = findViewById(R.id.btn_video);
    }
    private void videoCheck(){
        if (videoList != null){
            btnVideo.setVisibility(View.VISIBLE);
            btnVideo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(DetailsActivity.this,VideoActivity.class);
                    intent1.putExtra("youtubeid",videoList.get(0).getYoutubeId());
                    startActivity(intent1);
                }
            });
        }
    }
    private void galleryCheck(){
        if (galleryList != null){
            btnGallery.setVisibility(View.VISIBLE);
            btnGallery.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
}
