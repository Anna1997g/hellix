package com.example.taskexample.room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.taskexample.network.json.Metadatum;

import java.util.List;

@Dao
public interface MetadatumDao {
    @Insert
    void insert(Metadatum metadatum);
    @Delete
    void delete(Metadatum metadatum);
    @Query( "DELETE FROM metadatums"  )
    void deleteAll();
    @Query ( "SELECT * FROM metadatums" )
    LiveData<List<Metadatum>> getAllItems();
}
