package com.example.taskexample.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import com.example.taskexample.R;
import com.example.taskexample.glideUtils.GlideApp;
import com.example.taskexample.glideUtils.GlideUtils;
import com.example.taskexample.network.json.Metadatum;
import com.example.taskexample.network.utils.DateUtils;

import java.util.ArrayList;
import java.util.List;

import static com.example.taskexample.R.drawable.background_color;

public class MetadatumAdapter extends RecyclerView.Adapter<MetadatumAdapter.MyViewHolder> {

    private Context context;
    private List<Metadatum> metadatumList = new ArrayList<>();
    private onitemClicklListener listener;

    public onitemClicklListener getListener() {
        return listener;
    }

    public void setListener(onitemClicklListener listener) {
        this.listener = listener;
    }

    public MetadatumAdapter(Context context) {
        this.context = context;
    }

    public interface onitemClicklListener {
        void onItemClicked(int position);
    }

    public List<Metadatum> getMetadatumList() {
        return metadatumList;
    }

    public void setMetadatumList(List<Metadatum> metadatumList) {
        this.metadatumList = metadatumList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.metadatum_item, parent, false);
        return new MyViewHolder(view);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Metadatum currMetadatum = metadatumList.get(position);
        holder.tvTitle.setText(currMetadatum.getTitle());
        holder.tvCategory.setText(currMetadatum.getCategory());
        holder.tvDate.setText(DateUtils.setDate(currMetadatum.getDate().toString()));
        if (currMetadatum.getClicked() ){
            holder.constraintLayout.setBackgroundColor(background_color);
        }

        GlideUtils.setImage(holder.ivImage, currMetadatum.getCoverPhotoUrl(), 8);


//        GlideApp.with(context)
//                .load(currMetadatum.getCoverPhotoUrl())
//                .apply(new RequestOptions().override(50, 50))
//                .into(holder.ivImage);


//        Picasso.get().load("http://bravo.am/uploads/2015/02/top_337dbac155d79df8386bbc287188d6f2.jpg").resize(100,100)
//               .centerCrop() .noPlaceholder().into(holder.ivImage);
    }

    @Override
    public int getItemCount() {
        return metadatumList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivImage;
        private TextView tvTitle, tvCategory, tvDate;
        private ConstraintLayout constraintLayout;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.iv_image);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvCategory = itemView.findViewById(R.id.tv_category);
            tvDate = itemView.findViewById(R.id.tv_date);
            constraintLayout = itemView.findViewById(R.id.cl_root);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClicked(position);
                        }
                    }
                }
            });
        }
    }


}
