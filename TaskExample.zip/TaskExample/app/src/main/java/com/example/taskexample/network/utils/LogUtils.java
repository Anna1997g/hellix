package com.example.taskexample.network.utils;

import android.util.Log;

public class LogUtils {
    public static final String TAG = "ANN_TAG";
    public static void d(String value){
        //Log.d(string,)
        Log.d(TAG,value );
    }
}
