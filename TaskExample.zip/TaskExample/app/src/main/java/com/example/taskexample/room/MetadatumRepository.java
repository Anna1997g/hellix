package com.example.taskexample.room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.taskexample.network.json.Metadatum;

import java.util.List;

public class MetadatumRepository {
    private MetadatumDao metadatumDao;
    private LiveData<List<Metadatum>> allResults;

    public MetadatumRepository(Application application){
        metadatumDao =  MetadatumDatabase.getInstance ( application ).metadatumDao ();
        allResults = metadatumDao.getAllItems ();
    }
    public void insert(Metadatum metadatum){
        new InsertAsyncTask ( metadatumDao ).execute ( metadatum );

    }
    public void  delete(Metadatum metadatum){
        new DeleteAsyncTask ( metadatumDao ).execute ( metadatum );
    }
    public void deleteAll(){
        new DeleteAllAsyncTask ( metadatumDao ).execute (  );
    }
    public LiveData<List<Metadatum>> getAllResults(){
        new GetAllItemsAsyncTask ( metadatumDao ).execute (  );
        return allResults;
    }

    class InsertAsyncTask extends AsyncTask<Metadatum, Void, Void> {
        private MetadatumDao metadatumDao;

        public InsertAsyncTask(MetadatumDao metadatumDao){
            this.metadatumDao = metadatumDao;
        }

        @Override
        protected Void doInBackground(Metadatum... resultItems) {
            metadatumDao.insert ( resultItems[0] );
            return null;
        }
    }
    class DeleteAsyncTask extends AsyncTask<Metadatum, Void, Void> {
        private MetadatumDao metadatumDao;

        public DeleteAsyncTask(MetadatumDao metadatumDao){
            this.metadatumDao = metadatumDao;
        }

        @Override
        protected Void doInBackground(Metadatum... resultItems) {
            metadatumDao.delete ( resultItems[0] );
            return null;
        }
    }
    class DeleteAllAsyncTask extends AsyncTask<Void, Void, Void> {
        private MetadatumDao metadatumDao;

        public DeleteAllAsyncTask(MetadatumDao metadatumDao){
            this.metadatumDao = metadatumDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            metadatumDao.deleteAll ( );
            return null;
        }
    }
    class GetAllItemsAsyncTask extends AsyncTask<Void, Void, Void>{
        private MetadatumDao metadatumDao;

        public GetAllItemsAsyncTask(MetadatumDao metadatumDao){
            this.metadatumDao = metadatumDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            metadatumDao.getAllItems ();
            return null;
        }
    }
}
