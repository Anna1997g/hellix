package com.example.taskexample.network.retrofit;

import androidx.lifecycle.MutableLiveData;

import com.example.taskexample.network.json.BaseResult;
import com.example.taskexample.network.json.Metadatum;

import java.util.List;

public class RetrofitRepository implements RequestManager.OnSearchListener {
    private RequestApiService requestApiService;
    private MutableLiveData<List<Metadatum>> allResults;



    public RetrofitRepository(){
        requestApiService = RetrofitClient.getInstance().getRequestApiService();
        allResults = new MutableLiveData<>();
    }
    public void search() {

        RequestManager.search ( this );
    }

    public MutableLiveData<List<Metadatum>> getAllResults() {
        return allResults;
    }

    @Override
    public void onSearchSuccess(BaseResult baseResult) {
        allResults.setValue(baseResult.getMetadata());
    }

    @Override
    public void onFailure(String failureMsg) {

    }

    @Override
    public void onError(String msg) {

    }
}
