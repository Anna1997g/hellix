package com.example.taskexample.glideUtils;

import com.bumptech.glide.module.AppGlideModule;
import com.bumptech.glide.annotation.GlideModule;

@GlideModule
public final class MyAppGlideModule  extends AppGlideModule {

}
