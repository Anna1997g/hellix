package com.example.taskexample.network.json;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@Entity(tableName = "metadatums")
public class Metadatum implements Serializable{
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo
    private Boolean isClicked = false;
    @ColumnInfo
    @SerializedName("category")
    @Expose
    private String category;
    @ColumnInfo
    @SerializedName("title")
    @Expose
    private String title;
    @ColumnInfo
    @SerializedName("body")
    @Expose
    private String body;
    @SerializedName("shareUrl")
    @Expose
    private String shareUrl;
    @ColumnInfo
    @SerializedName("coverPhotoUrl")
    @Expose
    private String coverPhotoUrl;
    @ColumnInfo
    @SerializedName("date")
    @Expose
    private Integer date;
    @Ignore
    @SerializedName("gallery")
    @Expose
    private List<Gallery> gallery = null;
    @Ignore
    @SerializedName("video")
    @Expose
    private List<Video> video = null;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getCoverPhotoUrl() {
        return coverPhotoUrl;
    }

    public void setCoverPhotoUrl(String coverPhotoUrl) {
        this.coverPhotoUrl = coverPhotoUrl;
    }

    public Integer getDate() {
        return date;
    }

    public void setDate(Integer date) {
        this.date = date;
    }

    public List<Gallery> getGallery() {
        return gallery;
    }

    public void setGallery(List<Gallery> gallery) {
        this.gallery = gallery;
    }

    public List<Video> getVideo() {
        return video;
    }

    public void setVideo(List<Video> video) {
        this.video = video;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public Boolean getClicked() {
        return isClicked;
    }

    public void setClicked(Boolean clicked) {
        isClicked = clicked;
    }

    @Override
    public String toString() {
        return "Metadatum{" +
                "id=" + id +
                ", isClicked=" + isClicked +
                ", category='" + category + '\'' +
                ", title='" + title + '\'' +
                ", body='" + body + '\'' +
                ", shareUrl='" + shareUrl + '\'' +
                ", coverPhotoUrl='" + coverPhotoUrl + '\'' +
                ", date=" + date +
                ", gallery=" + gallery +
                ", video=" + video +
                '}';
    }
}

